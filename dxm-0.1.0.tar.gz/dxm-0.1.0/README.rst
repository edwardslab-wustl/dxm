DXM is a good piece of code
